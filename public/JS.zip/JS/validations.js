//references
//https://stackoverflow.com/questions/1531093/how-do-i-get-the-current-date-in-javascript

//this script will validate if both emails match
//which will therefore output an error message, plus an error message box within the page

//this will check if both emails match
function checkEmail() {
    let form = document.querySelector("#contactForm");
    let emailTyped = form.email.value;
    let confirmedEmail = form.confirmEmail.value;
    
    if (confirmedEmail === emailTyped && emailTyped.length > 0) {
        document.getElementById("errorEmail").style.display = "none";
        console.log("This was typed correctly");
    }
    if (confirmedEmail !== emailTyped && emailTyped.length > 0) {
        document.getElementById("errorEmail").style.display = "block";
        form.confirmEmail.setCustomValidity("Both emails do not match.\n" + "Please try again");
        console.log("please review your inputs!");
    }

}

//we check if the email is a day after todays date,
//and it must not be before today's date
//or even yesterdays date.
function validateDate() {
    let form = document.querySelector("#contactForm");
    let isDateValid = form.projectDate.value;

    //for more infomation about the date please visit: https://stackoverflow.com/questions/1531093/how-do-i-get-the-current-date-in-javascript 
    let today = new Date().toISOString().slice(0, 10)

    console.log(today);
    console.log(isDateValid);

    if (isDateValid > today) {
        document.getElementById("error").style.display = "none";
        console.log("date is valid");
    } else {
        document.getElementById("error").style.display = "block";
        document.getElementById("error").style.transitionDelay = "1.2s";
        form.projectDate.setCustomValidity("You must set the date after todays date.")
        console.log("You cannot register an appointment at the same day, or the during the day before!");
    }

    // if (isDateValid < testDate) {
    //     console.log("You cannot register the appointment during the day before!")
    // }
}