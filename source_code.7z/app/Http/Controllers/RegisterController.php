<?php

namespace App\Http\Controllers;

use App\Models\cvs;
use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class RegisterController extends Controller
{
    //
    public function create()
    {
        return view('register.create');
    }

    public function store()
    {
        //return request()->all();
        $data = request()->validate([
            'name' => 'required|max:100',
            'email' => 'required|email|max:100',
            'password' => 'required|min:8',
            'keyprogramming' => 'required|max:255',
            'profile' => 'required|max:500',
            'education' => 'required|max:500',
            'URLlinks' => 'required|max:500'
        ]);
        cvs::create(request(['name', 'email', 'password']));
        return redirect()->to('/');
    }


}
