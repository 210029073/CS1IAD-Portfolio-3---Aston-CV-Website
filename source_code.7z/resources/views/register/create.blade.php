<html lang="en">

    <head>
        <meta charset="utf-8"/>
        <title>Register</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>

    <body>
        <header>
            <h1>Register your CV Details</h1>
        </header>

        <section>
            <div>
                <form method="POST" action="/register" id="form">
                    @csrf
                    <label>Full Name</label>
                    <br/>
                    <input type="text" name="name" placeholder="Enter your full name"/>

                    <br/>
                    <br/>

                    <label>Email</label>
                    <br/>
                    <input type="email" name="email" placeholder="Enter your Email Address"/>

                    <br/>
                    <br/>

                    <label>Password</label>
                    <br/>
                    <input type="password" name="password" placeholder="Enter your password"/>

                    <br/>
                    <br/>

                    <label>Education</label>
                    <br/>
                    <textarea name="education" form="regForm"></textarea>

                    <br/>
                    <br/>

                    <label>Profile</label>
                    <br/>
                    <textarea name="profile" form="regForm"></textarea>

                    <br/>
                    <br/>

                    <label>URL Links</label>
                    <br/>
                    <textarea name="urlLinks" form="regForm"></textarea>

                    <br/>
                    <br/>

                    <input type="submit" value="Register"/>
                    <input type="reset" value="Reset" onclick="window.location.replace('register')"/>

                </form>
            </div>
        </section>
    </body>
</html>
